Six continuous categories from 24.mp4
Selected scope: original frames 15 through 524, 30 fps, 0.5-17.5 seconds.
The six half-open ranges cover every frame exactly once. No source motion is omitted.
The opening title is excluded. Clip 1 and practice playback begin directly at neutral instructor frame 15.
Each interior target boundary is the first original frame of the following clip.
The practice page uses one continuous master for identical framing and seamless boundary holds.
Actual teacher tracking and its limitations are separate from the video cuts.

step-01.mp4: 0.5000-6.5000 s | 15:195 | Open the left stance
step-02.mp4: 6.5000-9.5000 s | 195:285 | Raise both hands
step-03.mp4: 9.5000-13.3000 s | 285:399 | Lower both hands
step-04.mp4: 13.3000-14.5000 s | 399:435 | Turn and open the hands
step-05.mp4: 14.5000-15.5000 s | 435:465 | Circle and gather the hands
step-06.mp4: 15.5000-17.5000 s | 465:525 | Lift and extend the left heel
