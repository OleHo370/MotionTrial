import { createHash } from 'node:crypto';
import { readFile, lstat } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

// This utility never writes to the package or target project.
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const digest = bytes => createHash('sha256').update(bytes).digest('hex');
const inspect = async filename => {
  try {
    const info = await lstat(filename);
    if (!info.isFile() || info.isSymbolicLink()) return { invalid: 'not a regular file' };
    const bytes = await readFile(filename);
    return { bytes: bytes.length, sha256: digest(bytes) };
  } catch (error) { if (error.code === 'ENOENT') return null; throw error; }
};
const safePath = (directory, relative) => {
  if (path.isAbsolute(relative) || relative.split(/[\\/]/).includes('..')) throw new Error('Unsafe manifest path');
  const resolved = path.resolve(directory, relative);
  if (!resolved.startsWith(path.resolve(directory) + path.sep)) throw new Error('Path escaped its root');
  return resolved;
};
const same = (actual, expected) => actual?.sha256 === expected?.sha256 && actual?.bytes === expected?.bytes;
const manifest = JSON.parse(await readFile(path.join(root, 'manifest.json'), 'utf8'));
const contents = JSON.parse(await readFile(path.join(root, 'PACKAGE_CONTENTS.json'), 'utf8'));
const packageProblems = [];
for (const entry of contents.files) {
  if (!same(await inspect(safePath(root, entry.path)), entry)) packageProblems.push(entry.path);
}
const targetArgument = process.argv[2];
const report = { package: manifest.package, readOnly: true, packageFiles: contents.files.length, packageIntegrity: packageProblems.length ? 'FAIL' : 'PASS', packageProblems };
if (targetArgument) {
  const target = path.resolve(targetArgument);
  const changes = { readyToAdd: [], readyToPatch: [], alreadyCurrent: [], conflicts: [] };
  for (const entry of manifest.files) {
    const actual = await inspect(safePath(target, entry.path));
    if (same(actual, entry)) changes.alreadyCurrent.push(entry.path);
    else if (!actual && entry.change === 'added') changes.readyToAdd.push(entry.path);
    else if (entry.base && same(actual, entry.base)) changes.readyToPatch.push(entry.path);
    else changes.conflicts.push({ path: entry.path, reason: actual ? 'Target differs from both supplied version and original baseline; merge manually.' : 'Original target file is missing.', actual });
  }
  const requirements = JSON.parse(await readFile(path.join(root, 'requirements.json'), 'utf8'));
  const dependencyProblems = [];
  for (const entry of requirements.files) {
    const actual = await inspect(safePath(target, entry.path));
    if (!same(actual, entry)) dependencyProblems.push({ path: entry.path, reason: actual ? 'Existing dependency differs; review without overwriting teammate changes.' : 'Required baseline dependency is missing.' });
  }
  report.target = target;
  report.changes = changes;
  report.dependencies = { checked: requirements.files.length, problems: dependencyProblems };
  report.node = { current: process.version, supported: Number(process.versions.node.split('.')[0]) === 24 };
  report.result = packageProblems.length || changes.conflicts.length || dependencyProblems.length || !report.node.supported ? 'NEEDS_REVIEW' : 'PASS';
} else report.result = packageProblems.length ? 'FAIL' : 'PASS';
console.log(JSON.stringify(report, null, 2));
if (report.result !== 'PASS') process.exitCode = 2;
