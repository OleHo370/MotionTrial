import { expect, test, type Page } from '@playwright/test';
import type { PoseSample } from '../lib/imitation';
import type { TeachingPlaylist } from '../lib/teaching';

declare global {
  interface Window { __mirrorCameraRequests?: number }
}

const mediaLabels = [
  'Recorded reference movement',
  'Pose estimated from the reference clip',
  'Live camera preview',
  'Reference skeleton aligned to your body',
  'Pose estimated from the live camera',
];

/** Check the actual rendered transforms, including each video and overlay layer. */
async function expectSharedMirror(page: Page, mirrored: boolean) {
  const expected = mirrored ? 'matrix(-1, 0, 0, 1, 0, 0)' : 'none';
  for (const label of mediaLabels) {
    await expect(page.getByLabel(label).locator('..')).toHaveCSS('transform', expected);
    await expect(page.getByLabel(label)).toHaveCSS('transform', 'none');
  }
  const groups = await page.evaluate((labels) => {
    const nodes = labels.map((label) => document.querySelector(`[aria-label="${label}"]`)!);
    return {
      referenceSharesFrame: nodes[0].parentElement === nodes[1].parentElement,
      cameraSharesFrame: nodes.slice(2).every((node) => node.parentElement === nodes[2].parentElement),
    };
  }, mediaLabels);
  expect(groups).toEqual({ referenceSharesFrame: true, cameraSharesFrame: true });
}

async function practiceState(page: Page, teaching: boolean) {
  return page.locator('.practice-page').evaluate((root, guided) => {
    const video = document.querySelector<HTMLVideoElement>('[aria-label="Recorded reference movement"]')!;
    return {
      selection: root.getAttribute(guided ? 'data-step-id' : 'data-current-movement'),
      phase: root.getAttribute(guided ? 'data-step-phase' : 'data-phase'),
      confirmations: guided ? root.getAttribute('data-completed-steps') : root.querySelectorAll('[data-state="passed"]').length,
      src: video.currentSrc,
      time: video.currentTime,
      paused: video.paused,
    };
  }, teaching);
}

for (const mode of ['guided', 'forms'] as const) {
  test(`${mode}: mirror both views preserves the selected movement and learning state`, async ({ page }, testInfo) => {
    test.setTimeout(90_000);
    testInfo.annotations.push({ type: 'provenance', description: 'Real local instructor video and recorded reference observations. No camera is started and no physical-camera or human-imitation result is claimed. Rendered video/overlay transforms are checked in both practice modes.' });
    await page.addInitScript(() => {
      window.__mirrorCameraRequests = 0;
      const original = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
      navigator.mediaDevices.getUserMedia = async (constraints) => {
        window.__mirrorCameraRequests!++;
        return original(constraints);
      };
    });
    await page.goto(`/practice?mode=${mode}`);
    const teaching = mode === 'guided';
    const root = page.locator(teaching ? '.teaching-page' : '.practice-page');
    await expect(root).toHaveAttribute(teaching ? 'data-step-phase' : 'data-phase', 'ready', { timeout: 60_000 });
    const mirror = page.getByRole('checkbox', { name: 'Mirror both views', exact: true });
    await expect(mirror).not.toBeChecked();
    await expectSharedMirror(page, false);

    if (teaching) {
      // This audited asymmetric endpoint is the opening foot lift shown in the bug report.
      const response = await page.request.get('/practice-media/teaching-playlist.json');
      expect(response.ok()).toBe(true);
      const playlist = await response.json() as TeachingPlaylist;
      const step = playlist.steps.find((item) => item.parentFormOrder === 1 && item.stepOrder === 2)!;
      expect(step).toBeTruthy();
      await page.getByRole('button', { name: new RegExp(`^Practice step ${step.stepOrder}:`) }).click();
      await expect(root).toHaveAttribute('data-step-id', step.id);
      await expect(root).toHaveAttribute('data-step-phase', 'ready');
      await page.getByRole('button', { name: 'Watch slowly', exact: true }).click();
      await expect(root).toHaveAttribute('data-step-phase', 'watching');
      expect(await page.getByLabel('Recorded reference movement').evaluate((element) => (element as HTMLVideoElement).playbackRate)).toBe(0.5);
      await expect.poll(() => page.getByLabel('Recorded reference movement').evaluate((element) => (element as HTMLVideoElement).currentTime)).toBeGreaterThan(step.startSeconds + 0.1);
      await mirror.check();
      await expectSharedMirror(page, true);
      await expect(root).toHaveAttribute('data-step-id', step.id);
      await expect(root).toHaveAttribute('data-completed-steps', '0');
      await expect(root).toHaveAttribute('data-step-phase', 'imitating', { timeout: (step.endSeconds - step.startSeconds) * 2_000 + 10_000 });
      const targetTime = step.targetSeconds ?? step.endSeconds;
      expect(await page.getByLabel('Recorded reference movement').evaluate((element) => (element as HTMLVideoElement).paused)).toBe(true);
      expect(Math.abs((await practiceState(page, true)).time - targetTime)).toBeLessThan(0.1);

      const posesResponse = await page.request.get(`/practice-media/${step.parentFormId}.poses.json`);
      expect(posesResponse.ok()).toBe(true);
      const poses = await posesResponse.json() as { samples: PoseSample[] };
      const target = poses.samples.reduce((nearest, sample) => Math.abs(sample.tMs - targetTime * 1000) < Math.abs(nearest.tMs - targetTime * 1000) ? sample : nearest);
      const foot = target.landmarks.find((point) => point.index === 27)!;
      const leftHip = target.landmarks.find((point) => point.index === 23)!;
      const rightHip = target.landmarks.find((point) => point.index === 24)!;
      const hipX = (leftHip.x + rightHip.x) / 2;
      expect(foot.visibility).toBeGreaterThan(0.45);
      expect(foot.x - hipX, 'The real endpoint must be visibly asymmetric, so a mirror regression cannot hide in a neutral pose.').toBeGreaterThan(0.08);
      // Confirm that the displayed source overlay contains the actual recorded foot.
      await expect.poll(() => page.getByLabel('Pose estimated from the reference clip').evaluate((element, point) => {
        const canvas = element as HTMLCanvasElement;
        const pixels = canvas.getContext('2d')!.getImageData(Math.round(point.x * canvas.width) - 3, Math.round(point.y * canvas.height) - 3, 7, 7).data;
        for (let index = 0; index < pixels.length; index += 4) {
          if (pixels[index] > 190 && pixels[index + 1] > 110 && pixels[index + 2] < 170 && pixels[index + 3] > 80) return true;
        }
        return false;
      }, foot)).toBe(true);
      await page.screenshot({ path: testInfo.outputPath('asymmetric-held-target-mirrored.png'), fullPage: true });
      await mirror.uncheck();
      await expectSharedMirror(page, false);
      await page.screenshot({ path: testInfo.outputPath('asymmetric-held-target-unmirrored.png'), fullPage: true });
    } else {
      await page.getByRole('button', { name: /^Practice movement 2:/ }).click();
      await expect(root).toHaveAttribute('data-current-movement', '2');
      await expect(root).toHaveAttribute('data-phase', 'ready', { timeout: 60_000 });
    }

    const before = await practiceState(page, teaching);
    expect(before.paused).toBe(true);
    for (const mirrored of [true, false]) {
      await mirror.setChecked(mirrored);
      await expectSharedMirror(page, mirrored);
      expect(await practiceState(page, teaching)).toEqual(before);
    }
    expect(await page.evaluate(() => window.__mirrorCameraRequests)).toBe(0);
    await expect(page.getByRole('button', { name: 'Start camera', exact: true })).toBeEnabled();
  });
}
