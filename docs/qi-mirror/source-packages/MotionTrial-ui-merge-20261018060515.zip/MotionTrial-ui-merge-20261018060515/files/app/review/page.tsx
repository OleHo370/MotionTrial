import Queue from '@/components/Queue';

export default function ReviewWorkspace() {
  return <Queue />;
}
