import type { Metadata } from 'next';
import PracticeWorkspace from '../../components/PracticeWorkspace';
import '../game-type.css';
import '../landing.css';
import '../enter/enter.css';
import './practice.css';
import './practice-ink.css';
import './practice-completion.css';

export const metadata: Metadata = {
  title: '氣 mirror · Movement practice',
  description: 'Learn one small tai chi step at a time, with slow demonstrations, unlimited imitation time, and real pose overlays.',
};

export default function PracticePage() {
  return <PracticeWorkspace />;
}
