# Qi Mirror 首页源码合并包

版本：2026-10-18 · soft-ink。包含最新衬线标题、收敛后的水墨交互，以及白色封面进入深绿太极区的毛玻璃滚动过渡。

这是首页合并包。源码从已检查的最新预览提取，附齐首页需要的组件、样式、图片和字体。练习、选关、摄像头、后端和示范视频由主项目提供。

## 目录

- `source/app/`：首页入口 `page.tsx` 和完整样式。
- `source/components/`：首页组件、太极符号和 Canvas/WebGL 水墨实现。
- `public/landing-art/`：4 个生成水墨材质和 5 个静态降级图。
- `public/fonts/`：Instrument Serif、Manrope、中文字库及原始许可文件。
- `integration/`：可选基础样式和根布局示例，供对照合并。
- `docs/MERGE_GUIDE.md`：详细接入、路由和验收说明。
- `SOURCES_AI.md`：素材来源与 AI 贡献。
- `MANIFEST.json`、`verify-package.mjs`：文件清单和完整性校验。

## 给负责合并的同学

1. 先阅读 `docs/MERGE_GUIDE.md`。当前源码使用 React + TypeScript，入口按 Next.js App Router 编写。
2. 将 `source/app/` 和 `source/components/` 合并到项目对应目录。若使用 `src/`，就放进 `src/app/` 和 `src/components/`。已有同名共享文件先对照差异。
3. 将 `public/` 内容合并到项目根 `public/`，保留原目录和文件名；字体文件名包含方括号，请原样保留。
4. 保留项目原有布局、路由和配置，按指南接入首页；不要直接替换整个项目。
5. 在解压目录运行 `node verify-package.mjs` 检查文件完整性，再运行主项目自己的类型检查与构建。

包中已补齐 `QiSymbol.tsx` 和 `game-type.css` 两个共享依赖。没有附带 `node_modules`、开发服务、预览模拟接口、个人路径或对话记录。
