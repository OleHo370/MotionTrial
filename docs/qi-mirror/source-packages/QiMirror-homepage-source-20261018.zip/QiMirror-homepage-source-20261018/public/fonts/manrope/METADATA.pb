name: "Manrope"
designer: "Mikhail Sharanda"
license: "OFL"
category: "SANS_SERIF"
date_added: "2019-10-03"
fonts {
  name: "Manrope"
  style: "normal"
  weight: 400
  filename: "Manrope[wght].ttf"
  post_script_name: "Manrope-ExtraLight"
  full_name: "Manrope ExtraLight"
  copyright: "Copyright 2019 The Manrope Project Authors (https://github.com/googlefonts/manrope)"
}
subsets: "cyrillic"
subsets: "cyrillic-ext"
subsets: "greek"
subsets: "latin"
subsets: "latin-ext"
subsets: "menu"
subsets: "vietnamese"
axes {
  tag: "wght"
  min_value: 200.0
  max_value: 800.0
}
source {
  repository_url: "https://github.com/googlefonts/manrope"
  commit: "6f81ebecdf65e4463b798cc07b16a4f8d5216917"
  config_yaml: "sources/config.yaml"
}
