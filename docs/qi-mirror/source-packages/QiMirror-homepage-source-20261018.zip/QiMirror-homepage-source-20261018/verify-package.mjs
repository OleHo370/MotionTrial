import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const root=path.dirname(fileURLToPath(import.meta.url));
const manifest=JSON.parse(await fs.readFile(path.join(root,'MANIFEST.json'),'utf8'));
let failures=0;
for(const item of manifest.files){
  const file=path.resolve(root,item.path);
  if(!file.startsWith(root+path.sep))throw Error('Invalid package path');
  try{const data=await fs.readFile(file);if(data.length!==item.bytes||createHash('sha256').update(data).digest('hex')!==item.sha256)throw Error('Hash mismatch');}
  catch(error){failures++;console.error(item.path+': '+error.message);}
}
console.log(`${manifest.files.length} files checked; ${failures} failures.`);
if(failures)process.exitCode=1;
