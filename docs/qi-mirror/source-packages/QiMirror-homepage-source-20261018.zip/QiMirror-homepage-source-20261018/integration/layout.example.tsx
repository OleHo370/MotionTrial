// Reference only. Merge the base styles into your existing root layout; do not replace it.
import type { ReactNode } from 'react';
import './landing-base.css';
export default function RootLayout({children}: {children: ReactNode}) {
  return <html lang="en"><body>{children}</body></html>;
}
